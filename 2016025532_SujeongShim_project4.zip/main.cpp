/*
	id : 2016025532
	name : SujeongShim
	major : Computer Science and Engineering
*/

#define _CRT_SECURE_NO_WARNINGS
#include "newset.h"
#include <string>
#include <cstring>
#include <cstdlib>
using namespace std;

int main() {
	while (true) {
		string input;
		getline(cin, input);

		//char->number & add node to list
		char *av, *bv;
		LINK Ahead = new List();
		LINK Bhead = new List();
		Ahead->next = NULL; Bhead->next = NULL;
		IntSet Aset(Ahead), Bset(Bhead);

		char oper;
		bool op = false;
		string a(""), b("");
		for (unsigned int i = 0; i<(unsigned)input.size(); i++) {
			if (!strcmp(const_cast<char*>(input.c_str()), "0")) oper = '0';
			else {
				while (input[i] != NULL) {
					//get first set
					if (!op) {
						while (input[i++] != '}') {
							a += input[i];
						}
					}
					//find operator
					while (input[i] != '+' && input[i] != '-' && input[i] != '*') {
						i++;
					}
					if (input[i] == '+' || input[i] == '-' || input[i] == '*') {
						oper = input[i];
						op = true;
						i++;
					}
					//get second set
					if (op) {
						while (input[i++] != '}') {
							b += input[i];
						}
					}
				}
			}
			
		}

		//pasing first set ->int
		av = strtok(const_cast<char*>(a.c_str()), " ,{}");
		while (av != NULL) {
			Aset.addList(atoi(av));
			av = strtok(NULL, " ,{}");
		}
		
		//pasing second set ->int
		bv = strtok(const_cast<char*>(b.c_str()), " ,{}");
		while (bv != NULL) {
			Bset.addList(atoi(bv));
			bv = strtok(NULL, " ,{}");
		}

		//Operate
		LINK r = new List();
		r->next = NULL;
		IntSet result(r);
		if (oper == '+') {result=Aset+Bset; }
		else if (oper == '-') { result = Aset - Bset; }
		else if (oper == '*') { result = Aset * Bset; }
		else if (oper == '0') break;

		//Show result
		cout << result << endl;
	}
	return 0;
}

