#include "newset.h"

IntSet IntSet::operator+ (IntSet node) {
	LINK r = new List();
	r->next = NULL;
	IntSet res(r);
	for (LINK i = head->next; i != NULL; i = i->next) { //add node to result list
		res.addList(i->num);
	}
	for (LINK i = node.head->next; i != NULL; i = i->next) { //add node to result list
		res.addList(i->num);
	}
	res.sort(); //sorting result list
	return res;
}
IntSet IntSet::operator- (IntSet node) {
	LINK r = new List();
	r->next = NULL;
	IntSet res(r);
	for (LINK i = head->next; i != NULL; i = i->next) {
		bool co = false;
		for (LINK j = node.head->next; j != NULL; j = j->next) {
			if (i->num == j->num) { //check if there same value or not 
				co = true;
				break;
			}
		}
		if (!co) res.addList(i->num); //if there are not same value, add node to result list
	}
	res.sort(); //sorting the result
	return res;
}
IntSet IntSet::operator* (IntSet node) {
	LINK r = new List();
	r->next = NULL;
	IntSet res(r);
	for (LINK i = head->next; i != NULL; i = i->next) {
		bool co = false;
		for (LINK j = node.head->next; j != NULL; j = j->next) {
			if (i->num == j->num) { //check if there are same value or not
				co = true;
				break;
			}
		}
		if (co) res.addList(i->num); //if there are same value, add the node to result
	}
	res.sort(); //sort the result
	return res;
}

ostream& operator<< (ostream& out, IntSet node) {
	LINK cur = node.head->next;
	//first print { and print nodes, and print }
	out << '{';
	while (cur != NULL) {
		out << cur->num;
		if (cur->next != NULL) out << ",";
		cur = cur->next;
	}
	out << '}';
	return out;
}

void IntSet::addList(int n) { //add node to list
	LINK current = head;
	LINK node = new List();
	node->num = n;

	//check whether head->next null or not and if head->next is null, add new node to head->next
	if (head == NULL) {
		head = node;
		head->next = NULL;
	}
	else {
		//make current->next is null and add new node to current->next
		while (current->next != NULL) current = current->next;
		current->next = node;
		current->next->next = NULL;
	}

	//sorting nodes in list
	sort();
}

void IntSet::deleteList(LINK node) {
	LINK post = head;
	if (node == NULL);//check node is NULL
	else if (node == head->next) { //if node is only node of list, just delete node
		head->next = NULL;
	}
	else if (node != head->next && node->next != NULL) { //connect prev node and next node and delete node
		while (post->next != node) post = post->next;
		post->next = node->next;
	}
	else { //if node is last node of list, just delete node
		while (post->next != node) post = post->next;
		post->next = NULL;
	}
}

void IntSet::sort() {
	int temp;
	for (LINK i = head->next; i != NULL; i = i->next) {
		if (i->next != NULL) {
			for (LINK j = i->next; j != NULL; j = j->next) {
				if (i->num == j->num) { //if there are same value, delete one node
					deleteList(j);
				}
				else if (i->num > j->num) { //if after node's value is small than post node's value, change they're values.
					temp = i->num; i->num = j->num; j->num = temp;
				}
			}
		}
	}
}

IntSet::~IntSet() {
	LINK i=head;
	LINK current = i;
	while (i->next != NULL) {
		i = i->next;
		current=NULL;
	}
}