#ifndef __HERE__
#define __HERE__
#include <iostream>
#include <string>
using namespace std;

//linked list for saving the value of set
struct List {
	int num;
	List* next;
};
typedef List* LINK;

//IntSet for operating, saving list, etc.
class IntSet {
private:
	LINK head; //linked list for saving set value
	string s;
public:
	IntSet(LINK node) : head(node) {}; //init linked list
	IntSet operator+ (IntSet node); //+ operator operate
	IntSet operator- (IntSet node); //- operator operate
	IntSet operator* (IntSet node); //* operator operate
	friend ostream& operator<< (ostream& out, IntSet node); //<< operator for print
	void addList(int n); //add node to linked list
	void deleteList(LINK node); //delete node in linked list
	void sort(); //sorting by value in linked list, and delete node if there are same value
	~IntSet(); //memory init
};
#endif