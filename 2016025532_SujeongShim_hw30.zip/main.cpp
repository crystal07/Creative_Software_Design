#include <iostream>
#include <string>
#include "Minion.h"
using namespace std;

void parse(int *_array, string _input, char _delimiter) {
	int value = 0;
	int index = 0;
	for (int i = 0; i < _input.length(); ++i) {
		char c = _input[i];
		if (c >= '0' && c <= '9') {
			value *= 10;
			value += (int)(c - '0');
		}
		else if (c == _delimiter) {
			_array[index++] = value;
			value = 0;
		}
	}
	_array[index] = value;
}

int main() {

	while (true) {
		string input;
		getline(cin, input);
		if (input == "Q" || input == "q") break;

		int *data = new int[4];
		parse(data, input, ',');
		int leftDamage = data[0];
		int leftHP = data[1];
		int rightDamage = data[2];
		int rightHP = data[3];
		delete[] data;

		Minion left(leftHP, leftDamage), right(rightHP, rightDamage);
		bool leftDead = left.hit(right.damage());
		if (leftDead) cout << "Left Dead" << endl;
		else cout << "Left " << left.hp() << endl;

		bool rightDead = right.hit(left.damage());
		if (rightDead) cout << "Right Dead " << endl;
		else cout << "Right " << right.hp() << endl;
	}

	return 0;
}