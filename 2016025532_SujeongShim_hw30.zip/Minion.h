#pragma once

class Minion {
private :
	int HP;
	int Damage;
public :
	Minion(int hp, int damage);
	int hp() const;
	int damage() const;
	bool hit(int Damage);
	~Minion();
};