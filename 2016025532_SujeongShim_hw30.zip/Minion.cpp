#include <iostream>
#include "Minion.h"
using namespace std;

Minion::Minion(int hp, int damage) : HP(hp), Damage(damage) {};

int Minion::hp() const {
	return HP;
}

int Minion::damage() const {
	return Damage;
}

bool Minion::hit(int damage) /*ture when hp<=0*/ {
	HP -= damage;
	if (HP <= 0) return true;
	else return false;
}

Minion::~Minion() {}