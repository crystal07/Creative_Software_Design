#include "Shape.h"
#include <string>
#include <iostream>
using namespace std;

class ISOTriangle : public Shape {
public:
	ISOTriangle(string n) { name = n; }
	void draw(char brush, int width, int height);
};