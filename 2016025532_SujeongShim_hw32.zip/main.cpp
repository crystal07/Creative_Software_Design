#include "RATriangle.h"
#include "ISOTriangle.h"
#include "Rectangle.h"
#include "Shape.h"
#include <iostream>

using namespace std;

int main() {

	while (true) {
		int input;
		//ISO-triangle : �̵�ﰢ��
		//RA-triangle : �����ﰢ��
		cout << "Shape (1: Rectangle, 2: ISO-triangle, 3: RA-triangle, 0: Quit) : ";
		cin >> input;
		if (input == 0) break;

		char brush;
		cout << "Brush : ";
		cin >> brush;

		int width, height;
		cout << "Width, Height : ";
		cin >> width >> height;

		//print your shape here
		if (input == 1) {
			Rectangle rec("Rectangle");
			rec.draw(brush, width, height);
		}
		else if (input == 2) {
			ISOTriangle iso("ISOTriangle");
			iso.draw(brush, width, height);
		}
		else if (input == 3) {
			RATriangle ra("RATriangle");
			ra.draw(brush, width, height);
		}
	}

	return 0;
}