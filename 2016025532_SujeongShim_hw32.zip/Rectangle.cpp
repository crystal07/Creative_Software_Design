#include "Rectangle.h"
#include <iostream>
using namespace std;

void Rectangle::draw(char brush, int width, int height) {
	cout << "*** DRAWING " << name << " ***" << endl;
	for (int i = 0; i < height; i++) {
		for (int j = 0; j < width; j++) {
			cout << brush;
		}
		cout << endl;
	}
}

