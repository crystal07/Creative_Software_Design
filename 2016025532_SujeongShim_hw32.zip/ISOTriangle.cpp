#include "ISOTriangle.h"
#include <iostream>
using namespace std;

void ISOTriangle::draw(char brush, int width, int height) {
	cout << "*** DRAWING " << name << " ***" << endl;
	for (int i = 0; i < height; i++) {
		for (int j = height-1; j > i; j--) cout << ' ';
		for (int k = 0; k <= i; k++) cout << brush;
		for (int l = 0; l < i; l++) cout << brush;
		cout << endl;
	}
}