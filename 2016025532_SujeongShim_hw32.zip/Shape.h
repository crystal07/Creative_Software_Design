#ifndef SHAPE_H
#define SHAPE_H
#include <iostream>

class Shape {
public :
	Shape() { name = "shape"; }
	void draw(char brush, int width, int height);

protected :
	std::string name;
};

#endif