#include "Shape.h"
#include <string>
#include <iostream>
using namespace std;

class Rectangle : public Shape {
public:
	Rectangle(string n) { name = n; }
	void draw(char brush, int width, int height);
};
