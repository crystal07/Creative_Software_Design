#include "Shape.h"
#include <string>
using namespace std;

void Shape::draw(char brush, int width, int height) {
	cout << "*** DRAWING " << name << "***" << endl;
}