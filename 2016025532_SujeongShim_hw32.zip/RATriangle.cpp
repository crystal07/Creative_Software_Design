#include "RATriangle.h"
#include <iostream>
using namespace std;

void RATriangle::draw(char brush, int width, int height) {
	cout << "*** DRAWING " << name << " ***" << endl;
	for (int i = 0; i < height; i++) {
		for (int j = 0; j <= i; j++) {
			cout << brush;
		}
		cout << endl;
	}

}