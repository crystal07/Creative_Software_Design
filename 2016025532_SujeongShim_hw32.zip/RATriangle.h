#include "Shape.h"
#include <string>
#include <iostream>
using namespace std;

class RATriangle : public Shape {
public:
	RATriangle(string n) { name = n; }
	void draw(char brush, int width, int height);
};
