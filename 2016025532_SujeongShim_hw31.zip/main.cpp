#include <iostream>
#include "Area.h"
using namespace std;

int main() {

	int shape = -1;

	while (shape != 0) {
		//input shape
		cout << "Input your shape (1: circle, 2: triangle) (0 for quit) : ";
		cin >> shape;

		//get area
		switch (shape) {
		case 1:
			Area areaCircle;
			float r;
			cout << "Input radius : ";
			cin >> r;
			cout << areaCircle.area(r) << endl;;
			break;
		case 2:
			Area areaTriangular;
			float w, h;
			cout << "Input width, height : ";
			cin >> w >> h;
			cout << areaTriangular.area(w, h) << endl;
			break;
		default:
			break;
		}
	}

	return 0;
}