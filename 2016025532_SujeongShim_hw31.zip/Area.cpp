#include "Area.h"

float Area::area(float r) {
	return r*r*3.141592653589793;
}

float Area::area(float w, float h) {
	return w*h / 2;
}