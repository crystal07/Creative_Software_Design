#pragma once

class Area {
public:
	float area(float r); //circle
	float area(float w, float h); //triangle
};